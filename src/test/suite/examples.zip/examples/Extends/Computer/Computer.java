package Computer;

import Electronics;

public class Computer extends Electronics{
    Computer()
    {
        System.out.println("Computer");
        System.out.println("Computer");
        System.out.println("Computer");
        System.out.println("Computer");
        System.out.println("Computer");
        System.out.println("Computer");
        System.out.println("Computer");
        System.out.println("Computer");
        System.out.println("Computer");
        System.out.println("Computer");
        System.out.println("Computer");
        System.out.println("Computer");
        System.out.println("Computer");
        System.out.println("Computer");
    }
}

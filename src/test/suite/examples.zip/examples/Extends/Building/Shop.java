package Building;

public class Shop extends Building{
    Shop()
    {
        
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
        System.out.println("Shop");
    }
}

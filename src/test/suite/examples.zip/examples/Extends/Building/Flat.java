package Building;

public class Flat extends House {
    Flat(){
        
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
        System.out.println("Flat");
    }
}

package Building;

public class House extends Building{
    House(){
        
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
        System.out.println("House");
    }
}

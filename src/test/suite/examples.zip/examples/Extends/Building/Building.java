package Building;

public class Building {
    Building()
    {
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
        System.out.println("Building");
    }
}

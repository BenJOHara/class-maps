package Building;

public class School extends Building{
    School (){
        
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
        System.out.println("School");
    }
}

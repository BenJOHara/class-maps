package Vehicle;

public class Bike extends Vehicle {
    public int wheels = 2;

    Bike()
    {
        
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
        System.out.println("Bike");
    }
}

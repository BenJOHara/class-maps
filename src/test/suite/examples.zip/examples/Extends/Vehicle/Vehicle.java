package Vehicle;

class Vehicle {
    public int speed;
    public int seats;
    public int wheels;
    public int doors;


    Vehicle ()
    {
        System.out.println("Vehicle");
        System.out.println("Vehicle");
        System.out.println("Vehicle");
        System.out.println("Vehicle");
        System.out.println("Vehicle");
        System.out.println("Vehicle");
        System.out.println("Vehicle");
        System.out.println("Vehicle");
        System.out.println("Vehicle");
        System.out.println("Vehicle");
        System.out.println("Vehicle");
        System.out.println("Vehicle");
        System.out.println("Vehicle");
        System.out.println("Vehicle");
        System.out.println("Vehicle");
        System.out.println("Vehicle");

    }
}
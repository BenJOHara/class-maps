package Vehicle;

class Lorry extends Vehicle{
    public String cargo;


    Lorry(){

        
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
        System.out.println("Lorry");
    }
}
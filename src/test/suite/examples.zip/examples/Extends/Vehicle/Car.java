package Vehicle;

class Car extends Vehicle{
    public boolean convertable;
    Car(){
        
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
        System.out.println("Car");
    }
}
package Vehicle;

public class Motorbike extends Bike{
    boolean Engine = true;

    Motorbike()
    {
        
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
        System.out.println("Motorbike");
    }
}

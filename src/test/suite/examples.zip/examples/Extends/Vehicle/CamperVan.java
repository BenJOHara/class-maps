package Vehicle;

class CamperVan extends Van{
    public int beds;
    public boolean hardtop;

    public void stats (){
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
        System.out.println("CamperVan");
    }
}
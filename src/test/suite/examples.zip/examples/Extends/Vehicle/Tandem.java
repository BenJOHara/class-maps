package Vehicle;

public class Tandem extends Bike{
    Tandem()
    {
        
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
        System.out.println("Tandem");
    }
}

package Vehicle;

class Van extends Vehicle{
    public boolean refrigirated;


    Van(){
        
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
        System.out.println("van");
    }
}


public class Person{

    Person()
    {
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
        System.out.println("Person");
    }
}
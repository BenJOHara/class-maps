

public class Teacher extends Person{

    Teacher()
    {
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
        System.out.println("Teacher");
    }
}
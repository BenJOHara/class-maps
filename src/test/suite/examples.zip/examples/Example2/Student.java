
public class Student extends Person{

    Student()
    {
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
        System.out.println("Student");
    }
}
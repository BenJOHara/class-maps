

public class Dog{

    Dog()
    {
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        System.out.println("Dog");
        
    }
}